|    TAG    | COUNT |    AUTHOR     | COUNT | DIRECTORY  | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|---------------|-------|------------|-------|----------|-------|------|-------|
| cve       |  2907 | dhiyaneshdk   |  1571 | http       |  8302 | info     |  3996 | file |   404 |
| panel     |  1249 | daffainfo     |   866 | cloud      |   419 | high     |  2173 | dns  |    25 |
| wordpress |  1085 | dwisiswant0   |   803 | file       |   404 | medium   |  1877 |      |       |
| exposure  |  1044 | princechaddha |   569 | workflows  |   192 | critical |  1211 |      |       |
| xss       |   994 | ritikchaddha  |   523 | code       |   158 | low      |   289 |      |       |
| wp-plugin |   949 | pussycat0x    |   453 | network    |   138 | unknown  |    57 |      |       |
| osint     |   807 | pikpikcu      |   352 | javascript |    65 |          |       |      |       |
| tech      |   748 | pdteam        |   302 | dast       |    40 |          |       |      |       |
| lfi       |   735 | ricardomaia   |   245 | ssl        |    36 |          |       |      |       |
| misconfig |   721 | geeknik       |   232 | dns        |    22 |          |       |      |       |
