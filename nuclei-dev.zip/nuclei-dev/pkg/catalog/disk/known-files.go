package disk

var knownConfigFiles = []string{"cves.json", "contributors.json", "TEMPLATES-STATS.json"}
